-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 27, 2018 at 07:04 AM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `students_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `admin_id` int(11) NOT NULL,
  `admin_name` varchar(32) NOT NULL,
  `password` varchar(80) NOT NULL,
  `email` varchar(64) NOT NULL,
  `admin_photo` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`admin_id`, `admin_name`, `password`, `email`, `admin_photo`) VALUES
(1, 'nazir007', '$2y$10$O3njkEpIB0WnUARi3nBUPOwJkxDhlWSr9/GWh20bYUFBA2ydBKdMS', 'nazir@gmail.com', '1521954479Jellyfish.jpg'),
(9, 'tania007', '$2y$10$p2LyqxCPgVwNFH1C2JcbWewWXbXbIQKSKogPwI3WCmWAjp95f1fxC', 'taniajuthy@gmail.com', '1522124922Chrysanthemum.jpg'),
(10, 'mainul007', '$2y$10$P1qH29jhO8HebpMlwi3abe0MrJuA8FjrNeO/XsA4taY6QD.fQLqvy', 'mainul@gmail.com', '1522124950Penguins.jpg'),
(11, 'dipika007', '$2y$10$lFEptrDcsCnLm6M9vsvxyOvxYKeok23vtkZqxaE2E8.QvaLL/4WOG', 'faridayasminbrur@gmail.com', '1522126823Chrysanthemum.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `student_id` int(64) NOT NULL,
  `student_name` varchar(64) NOT NULL,
  `fathers_name` varchar(64) NOT NULL,
  `mothers_name` varchar(64) NOT NULL,
  `conct_num` int(250) NOT NULL,
  `emer_conct` int(250) NOT NULL,
  `email` varchar(64) NOT NULL,
  `present_add` varchar(100) NOT NULL,
  `permanent_add` varchar(100) NOT NULL,
  `student_photo` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`student_id`, `student_name`, `fathers_name`, `mothers_name`, `conct_num`, `emer_conct`, `email`, `present_add`, `permanent_add`, `student_photo`) VALUES
(3, 'AKbar ali', 'tgtytty', 'fgfrgrt', 235, 33435, 'taniajuthy@gmail.com', 'park', 'More', '1521953512Penguins.jpg'),
(4, 'sdsfdfd', 'dsewewe', 'ffrggfg', 23234, 34545, 'taniajuthy@gmail.com', 'zchhfg', 'parkmore', '1521953597Koala.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `teacher_id` int(255) NOT NULL,
  `teacher_name` varchar(250) NOT NULL,
  `teacher_desc` varchar(250) NOT NULL,
  `teacher_photo` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`teacher_id`, `teacher_name`, `teacher_desc`, `teacher_photo`) VALUES
(3, 'Hasan Ali', 'dfdfdfdf', '1521923869Jellyfish.jpg'),
(4, 'asdfgh', 'cdsddsdsdsdsvcv', '1521921194Hydrangeas.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`admin_id`),
  ADD UNIQUE KEY `username` (`admin_name`,`email`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`student_id`),
  ADD UNIQUE KEY `dept_name` (`student_id`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`teacher_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
