<?php session_start();?>

<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>Student Management System</title>

        <!-- Bootstrap core CSS -->
        <link href="css/bootstrap.min.css" rel="stylesheet">

        <!-- Custom styles for this template -->
        <link href="css/shop-homepage.css" rel="stylesheet">

    </head>

    <body>

        <!-- Navigation -->
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
            <div class="container">
                <a class="navbar-brand" href="dashboard.php">Student Management System</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <?php if (!empty($_SESSION)) { ?>
                        <ul class="navbar-nav ml-auto">
                            <li class="nav-item <?php if($page === 'dashboard') {echo 'active';}?>">
                                <a class="nav-link" href="dashboard.php">Dashboard
                                    <span class="sr-only">(current)</span>
                                </a>
                            </li>
                            <li class="nav-item <?php if($page === 'teachers') {echo 'active';}?>">
                                <a class="nav-link" href="teacher.php">Teachers</a>
                            </li>
                            <li class="nav-item <?php if($page === 'students') {echo 'active';}?>">
                                <a class="nav-link" href="student.php">Students</a>
                            </li>
                            <li class="nav-item <?php if($page === 'user') {echo 'active';}?>">
                                <a class="nav-link" href="user.php">Users</a>
                            </li>
                            <li class="nav-item <?php if($page === 'admin') {echo 'active';}?>">
                                <a class="nav-link" href="admin.php">Admins</a>
                            </li>

                            <a class="btn btn-danger" href="logout.php">Logout</a>

                        </ul>
                    <?php } else { ?>
<!--                        <div class="col-md-3 offset-9 float-right">
                            <a href="register.php" class="btn btn-info"> Register</a>&nbsp;&nbsp;
                            <a href="login.php" class="btn btn-warning" class="btn btn-waring"> Login</a>
                        </div>-->
                    <?php } ?>

                </div>
            </div>
        </nav>
