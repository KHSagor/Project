<?php
$page = 'teachers';
include 'connection.php';

$teacher_qry = $con->prepare("SELECT * FROM `teachers`");
$teacher_qry->execute();
$teacher_data = $teacher_qry->fetchAll();




?>

<?php include_once 'partials/header.php'; ?>
<!-- Page Content -->
<div class="container">

    <div class="row">

        <?php include_once 'partials/sidebar.php'; ?>
        <!-- /.col-lg-3 -->

        <div class="col-lg-9 col-md-9 mt-4 mb-4">
     
                <div class="alert alert-success">
                    <a href="add_teacher.php" class="btn btn-success">Add Teachers</a>
                </div>
            
            <table class="table table-bordered">
                <tr>
                    <th>Teacher ID</th>
                    <th>Teacher Name</th>
                    <th>Teacher Description</th>
                    <th>Teacher Photo</th>
                    <th>Action</th>
                </tr>
                <?php foreach($teacher_data as $v_teacher){?>
                <tr>
                    <td><?php echo $v_teacher['teacher_id']; ?></td>
                    <td><?php echo $v_teacher['teacher_name']; ?></td>
                    <td><?php echo $v_teacher['teacher_desc']; ?></td>
                    <td><img src="uploads/Teacher_photos/<?php echo $v_teacher['teacher_photo']; ?>" alt="
                             Teacher_photo" width="100"></td>
                    <td>
                        <a href="edit_teacher.php?id=<?php echo $v_teacher['teacher_id']; ?>">Edit</a>
                        <a href="delete_teacher.php?id=<?php echo $v_teacher['teacher_id']; ?>">Delete</a>
                    </td>
                </tr>
                <?php }?>
            </table>
    

        </div>
        <!-- /.col-lg-9 -->

    </div>
    <!-- /.row -->

</div>
<!-- /content container -->

<?php include_once 'partials/footer.php'; ?>