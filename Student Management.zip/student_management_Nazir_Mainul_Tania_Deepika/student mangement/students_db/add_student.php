<?php
$page = 'students';
include 'connection.php';
//TO get all cat info.
//$teacher_qry = $con->prepare("SELECT student_id,student_name FROM `Students`");
//$teacher_qry->execute();
//$teacher_data = $teacher_qry->fetchAll();

if (isset($_POST['add_student'])) {
    //take user input
    $student_id = trim($_POST['student_id']);
    $student_name = $_POST['student_name'];
    $fathers_name = trim($_POST['fathers_name']);
    $mothers_name = trim($_POST['mothers_name']);
    $conct_num = trim($_POST['conct_num']);
    $emer_conct = trim($_POST['emer_conct']);
    $email = trim($_POST['email']);
    $present_add = trim($_POST['present_add']);
    $permanent_add = trim($_POST['permanent_add']);
    $student_photo = "";
    $errors = [];
    $msgs = [];

    //Validate
    if (strlen(student_name) < 4) {
        $errors[] = "Student Name must be greater than 4 Chars!!";
    }

    //Image Upload
    if (isset($_FILES['student_photo']['tmp_name'])) {
        $student_photo = time() . $_FILES['student_photo']['name'];
        $tmp = $_FILES['student_photo']['tmp_name'];
        $dst = 'uploads/student_photo/' . $student_photo;

        move_uploaded_file($tmp, $dst);
    }

    //IF no error, DB upload
    if (empty($errors)) {

        $query = $con->prepare("INSERT INTO `students`(`student_id`,`student_name`,`fathers_name`,`mothers_name`,`conct_num`,`emer_conct`,`email`,`present_add`,`permanent_add`,`student_photo`) VALUES(:student_id,:student_name,:fathers_name,:mothers_name,:conct_num,:emer_conct,:email,:present_add,:permanent_add,:student_photo)");
        $query->bindValue(':student_id', $student_id);
        $query->bindValue(':student_name', $student_name);
        $query->bindValue(':fathers_name', $fathers_name);
        $query->bindValue(':mothers_name', $mothers_name);
        $query->bindValue(':conct_num', $conct_num);
        $query->bindValue(':emer_conct', $emer_conct);
        $query->bindValue(':email', $email);
        $query->bindValue(':present_add', $present_add);
        $query->bindValue(':permanent_add', $permanent_add);
        $query->bindValue(':student_photo', $student_photo);

        $query->execute();

        //Notify the user.
        if ($query->rowCount() === 1) {
            $msgs[] = "Student Added Successfully";
        } else {
            $errors[] = "Student could not be Added";
        }
    }
}
?>

<?php include_once 'partials/header.php'; ?>
<!-- Page Content -->
<div class="container">

    <div class="row">

        <?php include_once 'partials/sidebar.php'; ?>
        <!-- /.col-lg-3 -->

        <div class="col-lg-9 col-md-9 mt-4 mb-4">
            <p class="h3">Add Studentt</p>
            <?php if (!empty($errors)) { ?>
                <div class="alert alert-danger">
                    <?php foreach ($errors as $error) { ?>
                        <p><?php echo $error; ?></p>
                    <?php } ?>
                </div>
            <?php } ?>
            <?php if (!empty($msgs)) { ?>
                <div class="alert alert-success">
                    <?php foreach ($msgs as $msg) { ?>
                        <p><?php echo $msg; ?></p>
                    <?php } ?>
                </div>
            <?php } ?>
            <form action="" method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="student_id">Student ID</label>
                    <input class="form-control" type="text" name="student_id" id="student_id" required="">
                </div>
                <div class="form-group">
                    <label for="student_name">Student Name</label>
                    <input class="form-control" type="text" name="student_name" id="student_name" required="">
                </div>

                <div class="form-group">
                    <label for="fathers_name">Fathers Name</label>
                    <input class="form-control" type="text" name="fathers_name" id="fathers_name" required="">
                </div>
                <div class="form-group">
                    <label for="mothers_name">Mothers Name</label>
                    <input class="form-control" type="text" name="mothers_name" id="mothers_name" required="">
                </div>
                <div class="form-group">
                    <label for="conct_num">Contact Number</label>
                    <input class="form-control" type="text" name="conct_num" id="conct_num" required="">
                </div>
                <div class="form-group">
                    <label for="emer_conct">Emer Contact Number</label>
                    <input class="form-control" type="text" name="emer_conct" id="emer_conct" required="">
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input class="form-control" type="text" name="email" id="email" required="">
                </div>
                <div class="form-group">
                    <label for="present_add">Present Address</label>
                    <input class="form-control" type="text" name="present_add" id="present_add" required="">
                </div>
                <div class="form-group">
                    <label for="permanent_add">Permanent Address</label>
                    <input class="form-control" type="text" name="permanent_add" id="permanent_add" required="">
                </div>
                <div class="form-group">
                    <label for="student_photo">Student Photo</label>
                    <input class="form-control" type="file" name="student_photo" id="student_photo" required="">
                </div>


                <button class="btn btn-success" name="add_student">Add Student</button>
                <a href="student.php" class="btn btn-warning">Cancel</a>
            </form>


        </div>
        <!-- /.col-lg-9 -->

    </div>
    <!-- /.row -->
</div>
<!-- /content container -->

<?php include_once 'partials/footer.php'; ?>
