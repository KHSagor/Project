<?php
$page = 'admin';
include 'connection.php';

$stmt = $con->prepare("SELECT * FROM `admins`");
$stmt->execute();
$admins = $stmt->fetchAll()
?>

<?php include_once 'partials/header.php'; ?>
<!-- Page Content -->
<div class="container">

    <div class="row">

        <?php include_once 'partials/sidebar.php'; ?>
        <!-- /.col-lg-3 -->

        <div class="col-md-9 mt-4 mb-4">
          
             
                    <div class="alert alert-success">
                        <a href="add_teacher.php" class="btn btn-success">Add Teacher</a>
                    </div>

                    <table class="table table-bordered">
                        <tr>
                            <th>Admin ID</th>
                            <th>Admin Name</th>
                            <th>Admin Photo</th>
                            <th>Action</th>
                        </tr>

                        <?php foreach ($admins as $data) { ?>
                            <tr>
                                <td><?php echo $data['admin_id'] ?></td>
                                <td><?php echo $data['admin_name'] ?></td>
                                <td><img src="uploads/admin_photos/<?php echo $data['admin_photo'] ?>" alt="admin_photo" width="100"></td>
                                <td>
                                    <a href="edit_admin.php?id=<?php echo $data['admin_id']; ?>">Edit</a>
                                    <a href="delete_admin.php?id=<?php echo $data['admin_id']; ?>">Delete</a>
                                </td>
                            </tr>
                        <?php } ?>

                    </table>


            </div>
            <!-- /.col-lg-9 -->

        </div>
        <!-- /.row -->

    </div>
    <!-- /content container -->

    <?php include_once 'partials/footer.php'; ?>