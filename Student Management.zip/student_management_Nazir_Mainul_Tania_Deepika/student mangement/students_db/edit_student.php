<?php
$page = 'students';
include 'connection.php';

//To get all product data
$query = $con->prepare("SELECT * FROM `students` WHERE `student_id` = :student_id");
$query->bindValue(':student_id', $_GET['id'], PDO::PARAM_INT);
$query->execute();
$student_data = $query->fetch();


//$cat_qry = $con->prepare("SELECT * FROM `categories`");
//$cat_qry->execute();
//$cat_data = $cat_qry->fetchAll();

if (isset($_POST['edit_student'])) {
    //take user input
    $student_id = trim($_POST['student_id']);
    $student_name = trim($_POST['student_name']);
    $fathers_name = trim($_POST['fathers_name']);
    $mothers_name = trim($_POST['mothers_name']);
    $conct_num = trim($_POST['conct_num']);
    $emer_conct = trim($_POST['emer_conct']);
    $email = trim($_POST['email']);
    $present_add = trim($_POST['present_add']);
    $permanent_add = trim($_POST['permanent_add']);
    $student_photo = $student_data['student_photo'];
    $errors = [];
    $msgs = [];

    //Validate
    if (strlen($student_name) < 4) {
        $errors[] = "Student Name must be greater than 4 Chars!!";
    }

    //Image Upload
    if (isset($_FILES['student_photo']['tmp_name'])) {
        $student_photo = time() . $_FILES['student_photo']['name'];
        $tmp = $_FILES['student_photo']['tmp_name'];
        $dst = 'uploads/student_photo/' . $student_photo;

        move_uploaded_file($tmp, $dst);
    }

    //IF no error, DB upload
    if (empty($errors)) {

        $u_query = $con->prepare("UPDATE `students` SET `student_id` = :student_id,`student_name` = :student_name ,`fathers_name` = :fathers_name,`mothers_name` =:mothers_name,`conct_num` = :conct_num,`emer_conct` = :emer_conct, `email` = :email,`present_add` = :present_add,`permanent_add` = :permanent_add, `student_photo` = :student_photo WHERE `student_id` = :student_id ");
        $u_query->bindValue(':student_id', $_GET['id'], PDO::PARAM_INT);
        $u_query->bindValue(':student_name', $student_name);
        $u_query->bindValue(':fathers_name', $fathers_name);
        $u_query->bindValue(':mothers_name', $mothers_name);
        $u_query->bindValue(':conct_num', $conct_num);
        $u_query->bindValue(':emer_conct', $emer_conct);
        $u_query->bindValue(':email', $email);
        $u_query->bindValue(':present_add', $present_add);
        $u_query->bindValue(':permanent_add', $permanent_add);
        $u_query->bindValue(':student_photo', $student_photo);
        $u_query->execute();

        //Notify the user.
        if ($query->rowCount() === 1) {
            $msgs[] = "Student updated Successfully";
            //To get all updated product data
            $query = $con->prepare("SELECT * FROM `students` WHERE `student_id` = :student_id");
            $query->bindValue(':student_id', $_GET['id'], PDO::PARAM_INT);
            $query->execute();
            $student_data = $query->fetch();
        } else {
            $errors[] = "student could not be updated";
        }
    }
}
?>

<?php include_once 'partials/header.php'; ?>
<!-- Page Content -->
<div class="container">

    <div class="row">

        <?php include_once 'partials/sidebar.php'; ?>
        <!-- /.col-lg-3 -->

        <div class="col-lg-9 col-md-9 mt-4 mb-4">
            <p class="h3">Add Student</p>
            <?php if (!empty($errors)) { ?>
                <div class="alert alert-danger">
                    <?php foreach ($errors as $error) { ?>
                        <p><?php echo $error; ?></p>
                    <?php } ?>
                </div>
            <?php } ?>
            <?php if (!empty($msgs)) { ?>
                <div class="alert alert-success">
                    <?php foreach ($msgs as $msg) { ?>
                        <p><?php echo $msg; ?></p>
                    <?php } ?>
                </div>
            <?php } ?>
                <form action="" method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="student_id">Student ID</label>
                    <input class="form-control" type="text" name="student_id" id="student_id" value="<?php echo $student_data['student_id']; ?>" required="">
                </div>
                <div class="form-group">
                    <label for="student_name">Student Name</label>
                    <input class="form-control" type="text" name="student_name" id="student_name" value="<?php echo $student_data['student_name']; ?>" required="">
                </div>
                <div class="form-group">
                    <label for="fathers_name">Father Name</label>
                    <input class="form-control" type="text" name="fathers_name" id="fathers_name" value="<?php echo $student_data['fathers_name']; ?>" required="">
                </div>
                <div class="form-group">
                    <label for="mothers_name">Mother Name</label>
                    <input class="form-control" type="text" name="mothers_name" id="mothers_name" value="<?php echo $student_data['mothers_name']; ?>" required="">
                </div>
                <div class="form-group">
                    <label for="conct_num">Contact_num</label>
                    <input class="form-control" type="text" name="conct_num" id="conct_num" value="<?php echo $student_data['conct_num']; ?>" required="">
                </div>
                <div class="form-group">
                    <label for="emer_conct">Emer Contact Number</label>
                    <input class="form-control" type="text" name="emer_conct" id="emer_conct" value="<?php echo $student_data['emer_conct']; ?>" required="">
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input class="form-control" type="email" name="email" id="email" value="<?php echo $student_data['email']; ?>" required="">
                </div>
                <div class="form-group">
                    <label for="present_add">present Address</label>
                    <input class="form-control" type="text" name="present_add" id="present_add" value="<?php echo $student_data['present_add']; ?>" required="">
                </div>
                <div class="form-group">
                    <label for="permanent_add">Permanent Addresss</label>
                    <input class="form-control" type="text" name="permanent_add" id="permanent_add" value="<?php echo $student_data['permanent_add']; ?>" required="">
                </div>
               
                <div class="form-group">
                    <label for="student_photo">Student Photo</label>
                    <img src="uploads/student_photo/<?php echo $student_data['student_photo']; ?>" alt="student_photo" width="100">
                    <input class="form-control" type="file" name="student_photo" id="student_photo" >
                </div>

                <button class="btn btn-success" name="edit_student">Edit</button>
                <a href="student.php" class="btn btn-warning">Cancel</a>
            </form>


        </div>
        <!-- /.col-lg-9 -->

    </div>
    <!-- /.row -->

</div>
<!-- /content container -->

<?php include_once 'partials/footer.php'; ?>

