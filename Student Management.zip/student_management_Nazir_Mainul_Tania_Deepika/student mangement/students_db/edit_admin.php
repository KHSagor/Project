<?php
$page = 'admins';
include 'connection.php';
//Getting all info of the category.
$query = $con->prepare("SELECT * FROM `admins` WHERE `admin_id` = :admin_id");
$query->bindValue(':admin_id', $_GET['id'], PDO::PARAM_INT);
$query->execute();
$admin_data = $query->fetch();


if (isset($_POST['edit_admin'])) {
    //get user input
    $admin_id = $_POST['admin_id'];
    $admin_name = $_POST['admin_name'];
    $admin_photo = $admin_data['admin_photo'];
    $errors = [];
    $msgs = [];

    //Validate
    if (strlen($admin_name) < 4) {
        $errors[] = "Admin name must be greater than 4 chars!";
    } else {

        //If image uploaded
        if (!empty($_FILES['admin_photo']['tmp_name'])) {
            $admin_photo = time() . $_FILES['admin_photo']['name'];

            $dst = 'uploads/admin_photos/' . $admin_photo;

            move_uploaded_file($_FILES['admin_photo']['tmp_name'], $dst);
        }
        //if no errors,DB update
        $u_qry = $con->prepare("UPDATE `admins` SET `admin_id`=:admin_id,`admin_name`= :admin_name,`admin_photo`= :admin_photo WHERE `admin_id` = :admin_id");
        $u_qry->bindValue(':admin_id', $_GET['id'], PDO::PARAM_INT);
        $u_qry->bindValue(':admin_name', $admin_name);
        $u_qry->bindValue(':admin_photo', $admin_photo);
        $u_qry->execute();

        //Checking for success
        if ($u_qry->rowCount() === 1) {
            $msgs[] = "Admins Updated SUccessfully!";
            //Getting updated info of the category.
            $query = $con->prepare("SELECT * FROM `admins` WHERE `admin_id` = :admin_id");
            $query->bindValue(':admin_id', $_GET['id'], PDO::PARAM_INT);
            $query->execute();
            $admin_data = $query->fetch();
        } else {
            $errors[] = "Update failed!";
        }
    }
}
?>

<?php include_once 'partials/header.php'; ?>
<!-- Page Content -->
<div class="container">

    <div class="row">

        <?php include_once 'partials/sidebar.php'; ?>
        <!-- /.col-lg-3 -->

        <div class="col-lg-9 col-md-9 mt-4 mb-4">
            <p class="h3">Add Admin</p>
            <?php if (!empty($errors)) { ?>
                <div class="alert alert-danger">
                    <?php foreach ($errors as $error) { ?>
                        <p><?php echo $error; ?></p>
                    <?php } ?>
                </div>
            <?php } ?>
            <?php if (!empty($msgs)) { ?>
                <div class="alert alert-success">
                    <?php foreach ($msgs as $msg) { ?>
                        <p><?php echo $msg; ?></p>
                    <?php } ?>
                </div>
            <?php } ?>
            <form action="" method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="admin_id">Admin ID</label>
                    <input class="form-control" type="text" name="admin_id" id="admin_id" value="<?php echo $admin_data['admin_id']; ?>" required="">
                </div>
                <div class="form-group">
                    <label for="admin_name">Admin Name</label>
                    <input class="form-control" type="text" name="admin_name" id="admin_name" value="<?php echo $admin_data['admin_name']; ?>" required="">
                </div>
               
                <div class="form-group">
                    <label for="admin_photo">Admin Photo</label>
                    <img src="uploads/admin_photos/<?php echo $admin_data['admin_photo']; ?>" alt="admin_photo" width="100">
                    <input class="form-control" type="file" name="admin_photo" id="admin_photo" >
                </div>

                <button class="btn btn-success" name="edit_admin">Edit</button>
                <a href="admin.php" class="btn btn-warning">Cancel</a>
            </form>


        </div>
        <!-- /.col-lg-9 -->

    </div>
    <!-- /.row -->

</div>
<!-- /content container -->

<?php include_once 'partials/footer.php'; ?>

