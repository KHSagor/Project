<?php
$page = 'teachers';
include 'connection.php';
//Getting all info of the category.
$query = $con->prepare("SELECT * FROM `teachers` WHERE `teacher_id` = :teacher_id");
$query->bindValue(':teacher_id', $_GET['id'], PDO::PARAM_INT);
$query->execute();
$teacher_data = $query->fetch();


if (isset($_POST['edit_teacher'])) {
    //get user input
    $teacher_id = $_POST['teacher_id'];
    $teacher_name = $_POST['teacher_name'];
    $teacher_desc = $_POST['teacher_desc'];
    $teacher_photo = $teacher_data['teacher_photo'];
    $errors = [];
    $msgs = [];

    //Validate
    if (strlen($teacher_name) < 4) {
        $errors[] = "teacher name must be greater than 4 chars!";
    } else {

        //If image uploaded
        if (!empty($_FILES['teacher_photo']['tmp_name'])) {
            $teacher_photo = time() . $_FILES['teacher_photo']['name'];

            $dst = 'uploads/teacher_photos/' . $teacher_photo;

            move_uploaded_file($_FILES['teacher_photo']['tmp_name'], $dst);
        }
        //if no errors,DB update
        $u_qry = $con->prepare("UPDATE `teachers` SET `teacher_id`=:teacher_id,`teacher_name`= :teacher_name,`teacher_desc`= :teacher_desc,`teacher_photo`= :teacher_photo WHERE `teacher_id` = :teacher_id");
        $u_qry->bindValue(':teacher_id', $_GET['id'], PDO::PARAM_INT);
        $u_qry->bindValue(':teacher_name', $teacher_name);
        $u_qry->bindValue(':teacher_desc', $teacher_desc);
        $u_qry->bindValue(':teacher_photo', $teacher_photo);
        $u_qry->execute();

        //Checking for success
        if ($u_qry->rowCount() === 1) {
            $msgs[] = "Teacher Updated SUccessfully!";
            //Getting updated info of the category.
            $query = $con->prepare("SELECT * FROM `teachers` WHERE `teacher_id` = :teacher_id");
            $query->bindValue(':teacher_id', $_GET['id'], PDO::PARAM_INT);
            $query->execute();
            $teacher_data = $query->fetch();
        } else {
            $errors[] = "Update failed!";
        }
    }
}
?>

<?php include_once 'partials/header.php'; ?>
<!-- Page Content -->
<div class="container">

    <div class="row">

        <?php include_once 'partials/sidebar.php'; ?>
        <!-- /.col-lg-3 -->

        <div class="col-lg-9 col-md-9 mt-4 mb-4">
            <p class="h3">Add Teachers</p>
            <?php if (!empty($errors)) { ?>
                <div class="alert alert-danger">
                    <?php foreach ($errors as $error) { ?>
                        <p><?php echo $error; ?></p>
                    <?php } ?>
                </div>
            <?php } ?>
            <?php if (!empty($msgs)) { ?>
                <div class="alert alert-success">
                    <?php foreach ($msgs as $msg) { ?>
                        <p><?php echo $msg; ?></p>
                    <?php } ?>
                </div>
            <?php } ?>
            <form action="" method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="teacher_name">Teacher Name</label>
                    <input class="form-control" type="text" name="teacher_name" id="teacher_name" value="<?php echo $teacher_data['teacher_name']; ?>" required="">
                </div>
                <div class="form-group">
                    <label for="teacher_desc">Teacher Description</label>
                    <input class="form-control" type="text" name="teacher_desc" value="<?php echo $teacher_data['teacher_desc']; ?>" id="teacher_desc" required="">
                </div>
                <div class="form-group">
                    <label for="teacher_photo">Teacher Photo</label>
                    <img src="uploads/teacher_photos/<?php echo $teacher_data['teacher_photo']; ?>" alt="teacher_photo" width="100">
                    <input class="form-control" type="file" name="teacher_photo" id="teacher_photo" >
                </div>

                <button class="btn btn-success" name="edit_teacher">Edit</button>
                <a href="teacher.php" class="btn btn-warning">Cancel</a>
            </form>


        </div>
        <!-- /.col-lg-9 -->

    </div>
    <!-- /.row -->

</div>
<!-- /content container -->

<?php include_once 'partials/footer.php'; ?>

