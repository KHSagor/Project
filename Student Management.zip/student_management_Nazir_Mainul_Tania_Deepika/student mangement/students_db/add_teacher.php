<?php
$page = 'teachers';
include 'connection.php';
if (isset($_POST['add_teacher'])) {
    //take user input
    $teacher_id = trim($_POST['teacher_id']);
    $teacher_name = trim($_POST['teacher_name']);
    $teacher_desc = trim($_POST['teacher_desc']);
    $teacher_photo = "";
    $errors = [];
    $msgs = [];

    //Validate
    if (strlen($teacher_name) < 4) {
        $errors[] = "Teacher Name must be greater than 4 Chars!!";
    }

    //Image Upload
    if (isset($_FILES['teacher_photo']['tmp_name'])) {
        $teacher_photo = time() . $_FILES['teacher_photo']['name'];
        $tmp = $_FILES['teacher_photo']['tmp_name'];
        $dst = 'uploads/teacher_photos/' . $teacher_photo;

        move_uploaded_file($tmp, $dst);
    }

    //IF no error, DB upload
    if (empty($errors)) {

        $query = $con->prepare("INSERT INTO `teachers`(`teacher_id`,`teacher_name`,`teacher_desc`,`teacher_photo`) VALUES(:teacher_id,:teacher_name,:teacher_desc,:teacher_photo)");
        $query->bindValue(':teacher_id', $teacher_id);
        $query->bindValue(':teacher_name', $teacher_name);
        $query->bindValue(':teacher_desc', $teacher_desc);
        $query->bindValue(':teacher_photo', $teacher_photo);
        $query->execute();

        //Notify the user.
        if ($query->rowCount() === 1) {
            $msgs[] = "Teacher Added Successfully";
        } else {
            $errors[] = "Teacher could not be Added";
        }
    }
}
?>

<?php include_once 'partials/header.php'; ?>
<!-- Page Content -->
<div class="container">

    <div class="row">

        <?php include_once 'partials/sidebar.php'; ?>
        <!-- /.col-lg-3 -->

        <div class="col-lg-9 col-md-9 mt-4 mb-4">
            <p class="h3">Add Teacher</p>
            <?php if (!empty($errors)) { ?>
                <div class="alert alert-danger">
                    <?php foreach ($errors as $error) { ?>
                        <p><?php echo $error; ?></p>
                    <?php } ?>
                </div>
            <?php } ?>
            <?php if (!empty($msgs)) { ?>
                <div class="alert alert-success">
                    <?php foreach ($msgs as $msg) { ?>
                        <p><?php echo $msg; ?></p>
                    <?php } ?>
                </div>
            <?php } ?>
            <form action="" method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="teacher_id">Taecher ID</label>
                    <input class="form-control" type="text" name="teacher_id" id="teacher_id" required="">
                </div>
                <div class="form-group">
                    <label for="teacher_name">Taecher Name</label>
                    <input class="form-control" type="text" name="teacher_name" id="teacher_name" required="">
                </div>
                <div class="form-group">
                    <label for="teacher_desc">Teacher Description</label>
                    <input class="form-control" type="text" name="teacher_desc" id="teacher_desc" required="">
                </div>
                <div class="form-group">
                    <label for="teacher_photo">Teacher Photo</label>
                    <input class="form-control" type="file" name="teacher_photo" id="teacher_photo" >
                </div>

                <button class="btn btn-success" name="add_teacher">Add Teacher</button>
                <a href="teacher.php" class="btn btn-warning">Cancel</a>
            </form>


        </div>
        <!-- /.col-lg-9 -->

    </div>
    <!-- /.row -->

</div>
<!-- /content container -->

<?php include_once 'partials/footer.php'; ?>
