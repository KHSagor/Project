<?php
$page = 'students';
include 'connection.php';


//To get all product data
$student_qry = $con->prepare("SELECT * FROM `students`");
$student_qry->execute();
$student_data = $student_qry->fetchAll();
?>

<?php include_once 'partials/header.php'; ?>
<!-- Page Content -->
<div class="container">

    <div class="row">

        <?php include_once 'partials/sidebar.php'; ?>
        <!-- /.col-lg-3 -->

        <div class="col-lg-9 col-md-9 mt-4 mb-4">

            <div class="alert alert-success">
                <a href="add_student.php" class="btn btn-success">Add Students</a>
            </div>

            <table class="table table-bordered">
                <tr>
                    <th>Student ID</th>
                    <th>Student Name</th>
                    <th>Fathers Name</th>
                    <th>Mothers Name</th>
                    <th>Contact Number </th>
                    <th>Emer Contact Number </th>
                    <th>Email </th>
                    <th>Present Address </th>
                    <th>Permanent Address </th>
                    <th>Student Photo </th>
                    <th>Action</th>
                </tr>

                <?php foreach ($student_data as $v) { ?>

                    <tr>
                        <td><?php echo $v['student_id'] ?></td>
                        <td><?php echo $v['student_name'] ?></td>
                        <td><?php echo $v['fathers_name'] ?></td>
                        <td><?php echo $v['mothers_name'] ?></td>
                        <td><?php echo $v['conct_num'] ?></td>
                        <td><?php echo $v['emer_conct'] ?></td>
                        <td><?php echo $v['email'] ?></td>
                        <td><?php echo $v['present_add'] ?></td>
                        <td><?php echo $v['permanent_add']; ?></td>
                        <td><img src="uploads/student_photo/<?php echo $v['student_photo'] ?>" alt="student_photo" width="100"></td>
                        <td>
                            <a href="edit_student.php?id=<?php echo $v['student_id']; ?>">Edit</a>
                            <a href="delete_student.php?id=<?php echo $v['student_id']; ?>">Delete</a>
                        </td>
                    </tr>
                <?php } ?>
            </table>


        </div>
        <!-- /.col-lg-9 -->

    </div>
    <!-- /.row -->

</div>
<!-- /content container -->

<?php include_once 'partials/footer.php'; ?>