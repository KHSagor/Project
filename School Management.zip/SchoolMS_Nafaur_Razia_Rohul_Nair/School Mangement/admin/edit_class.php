<?php
$page = 'classes';
include 'connection.php';
//Getting all info of the category.
$query = $con->prepare("SELECT * FROM `classes` WHERE `class_id` = :class_id");
$query->bindValue(':class_id', $_GET['id'], PDO::PARAM_INT);
$query->execute();
$c_data = $query->fetch();


if (isset($_POST['edit_class'])) {
    //get user input
    $c_name = $_POST['class_name'];
    $c_desc = $_POST['description'];
    $errors = [];
    $msgs = [];

    //Validate
    
        //if no errors,DB update
        $u_qry = $con->prepare("UPDATE `classes` SET `class_name`= :class_name,`description`= :description WHERE `class_id` = :cId");
        $u_qry->bindValue(':cId', $_GET['id'], PDO::PARAM_INT);
        $u_qry->bindValue(':class_name', $c_name);
        $u_qry->bindValue(':description', $c_desc);
        $u_qry->execute();

        //Checking for success
        if ($u_qry->rowCount() === 1) {
            $msgs[] = "Class Updated SUccessfully!";
            //Getting updated info of the category.
            $query = $con->prepare("SELECT * FROM `classes` WHERE `class_id` = :class_id");
            $query->bindValue(':class_id', $_GET['id'], PDO::PARAM_INT);
            $query->execute();
            $t_data = $query->fetch();
        } else {
            $errors[] = "Update failed!";
        }
    }

?>

<?php include_once 'partials/header.php'; ?>
<!-- Page Content -->
<div class="container">

    <div class="row">

<?php include_once 'partials/sidebar.php'; ?>
        <!-- /.col-lg-3 -->

        <div class="col-lg-9 col-md-9 mt-4 mb-4">
            <p class="h3">Add Class</p>
<?php if (!empty($errors)) { ?>
                <div class="alert alert-danger">
                <?php foreach ($errors as $error) { ?>
                        <p><?php echo $error; ?></p>
                    <?php } ?>
                </div>
                <?php } ?>
            <?php if (!empty($msgs)) { ?>
                <div class="alert alert-success">
                <?php foreach ($msgs as $msg) { ?>
                        <p><?php echo $msg; ?></p>
                    <?php } ?>
                </div>
                <?php } ?>
            <form action="" method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="class_name">Class Name</label>
                    <input class="form-control" type="text" name="class_name" id="class_name" value="<?php echo $c_data['class_name']; ?>" required="">
                </div>
                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea class="form-control" name="description"><?php echo $c_data['description']; ?></textarea>
                </div>
                
                <button class="btn btn-success" name="edit_class">Edit</button>
                <a href="class.php" class="btn btn-warning">Cancel</a>
            </form>


        </div>
        <!-- /.col-lg-9 -->

    </div>
    <!-- /.row -->

</div>
<!-- /content container -->

<?php include_once 'partials/footer.php'; ?>

