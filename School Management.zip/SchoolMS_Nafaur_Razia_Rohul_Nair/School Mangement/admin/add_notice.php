<?php
$page = 'notice';
include 'connection.php';
if (isset($_POST['add_notice'])) {
    //take user input
    $notice_head = trim($_POST['notice_head']);
    $full_desc = trim($_POST['full_desc']);
    $notice_photo = "";
    $errors = [];
    $msgs = [];

    //Validate
    if (strlen($notice_head) < 4) {
        $errors[] = "Notice Head must be greater than 4 Chars!!";
    }

    //Image Upload
    if (isset($_FILES['notice_photo']['tmp_name'])) {
        $notice_photo = time() . $_FILES['notice_photo']['name'];
        $tmp = $_FILES['notice_photo']['tmp_name'];
        $dst = '../uploads/notice_photos/' . $notice_photo;

        move_uploaded_file($tmp, $dst);
    }

    //IF no error, DB upload
    if (empty($errors)) {

        $query = $con->prepare("INSERT INTO `notices`(`notice_head`,`full_desc`,`notice_photo`) VALUES(:notice_head,:full_desc,:notice_photo)");
        $query->bindValue('notice_head', $notice_head);
        $query->bindValue('full_desc', $full_desc);
        $query->bindValue('notice_photo', $notice_photo);
        $query->execute();

        //Notify the user.
        if ($query->rowCount() === 1) {
            $msgs[] = "Notices Added Successfully";
        } else {
            $errors[] = "Notices could not be Added";
        }
    }
}
?>

<?php include_once 'partials/header.php'; ?>
<!-- Page Content -->
<div class="container">

    <div class="row">

        <?php include_once 'partials/sidebar.php'; ?>
        <!-- /.col-lg-3 -->

        <div class="col-lg-9 col-md-9 mt-4 mb-4">
            <p class="h3">Add Notice</p>
            <?php if (!empty($errors)) { ?>
                <div class="alert alert-danger">
                    <?php foreach ($errors as $error) { ?>
                        <p><?php echo $error; ?></p>
                    <?php } ?>
                </div>
            <?php } ?>
            <?php if (!empty($msgs)) { ?>
                <div class="alert alert-success">
                    <?php foreach ($msgs as $msg) { ?>
                        <p><?php echo $msg; ?></p>
                    <?php } ?>
                </div>
            <?php } ?>
            <form action="" method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="notice_head">Notice Head</label>
                    <input class="form-control" type="text" name="notice_head" id="notice_head" required="">
                </div>
                <div class="form-group">
                    <label for="full_desc">Full Description</label>
                    <input class="form-control" type="text" name="full_desc" id="full_desc" required="">
                </div>
                <div class="form-group">
                    <label for="notice_photo">Notice photo</label>
                    <input class="form-control" type="file" name="notice_photo" id="notice_photo" >
                </div>
                <button class="btn btn-success" name="add_notice">Add notice</button>
                <a href="notice.php" class="btn btn-warning">Cancel</a>
            </form>


        </div>
        <!-- /.col-lg-9 -->

    </div>
    <!-- /.row -->

</div>
<!-- /content container -->

<?php include_once 'partials/footer.php'; ?>
