<?php

include 'partials/header.php';
require 'connection.php';
?>

<?php
if (isset($_POST['login'])) {
    //take user input
    $uname = trim($_POST['uname']);
    $password = trim($_POST['password']);
    $errors = [];
    $msgs = [];


    //Validate
    if (strlen($uname) < 6) {
        $errors[] = "Username must be greater than  6 Chars!!";
    }
    if (strlen($password) < 6) {
        $errors[] = "Password must be greater than  6 Chars!!";
    }
    //IF no error, DB upload
    if (empty($errors)) {
        $query = $con->prepare("SELECT `admin_id`,`email`,`password` FROM `admins` WHERE `admin_name` = :uname");
        $query->bindValue(':uname', strtolower($uname));
        $query->execute();
        $udata = $query->fetch();

        //Notify the user.
        if ($query->rowCount() === 1 && password_verify($password, $udata['password'])) {
            $_SESSION['username'] = $uname;
            $_SESSION['id'] = $udata['admin_id'];
            header('Location: dashboard.php');
        } else {
            $errors[] = "No user found with this name.";
        }
    }
}

//IF no error, DB upload
?>


<!-- Page Content -->
<div class="container">
    <div class="row">

        <!-- /.col-lg-3 -->
        <div class="col-lg-12">

            <div class="row">
                <div class="col-md-4 mt-4 mb-4 mx-auto">
                    <form action="" method="post">
                        <div class="form-group">
                            <label for="uname">Username</label>
                            <input class="form-control" type="text" name="uname" id="uname" required="">
                        </div>
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input class="form-control" name="password" id="password" type="password" required="">
                        </div>
                        <button class="btn btn-success" name="login">Login</button>
                        <a href="register.php" class="btn btn-info">Register</a>
                    </form>
                </div>

            </div>
            <!-- /.row -->
        </div>
        <!-- /.col-lg-9 -->
    </div>
    <!-- /.row -->
</div>
<!-- /.container -->
<?php include 'partials/footer.php'; ?>
