<?php
$page = 'notices';
include 'connection.php';
$n_qry = $con->prepare("SELECT * FROM `notices` ");
$n_qry->execute();
$n_data = $n_qry->fetchAll();
?>

<?php include_once 'partials/header.php'; ?>
<!-- Page Content -->
<div class="container">

    <div class="row">

        <?php include_once 'partials/sidebar.php'; ?>
        <!-- /.col-lg-3 -->

        <div class="col-md-9 mt-4 mb-4">
            <div class="alert alert-success">
                <a href="add_notice.php" class="btn btn-success">Add Notice</a>
            </div>
            <table class="table table-bordered">
                <tr>
                    <th>Notice ID</th>
                    <th>Notice Head</th>
                    <th>Full Description</th>
                    <th>Notice Photo</th>
                    <th>Time</th>

                    <th>Action</th>
                </tr>
                <?php foreach ($n_data as $notice) { ?>
                    <tr>
                        <td><?php echo $notice['notice_id']; ?></td>
                        <td><?php echo $notice['notice_head']; ?></td>
                        <td><?php echo $notice['full_desc']; ?></td>
                        <td><?php echo $notice['created_at']; ?></td>

                        <td><img src="../uploads/notice_photos/<?php echo $notice['notice_photo']; ?>" alt="
                                 notice_photo" width="100"></td>
                        <td>
                            <a href="edit_notice.php?id=<?php echo $notice['notice_id']; ?>">Edit</a>
                            <a href="delete_notice.php?id=<?php echo $notice['notice_id']; ?>">Delete</a>
                        </td>
                    </tr>
                <?php } ?>
            </table>
            <!-- /.row -->

        </div>
        <!-- /.col-lg-9 -->

    </div>
    <!-- /.row -->

</div>
<!-- /content container -->

<?php include_once 'partials/footer.php'; ?>
</div>
<!-- /.row -->


