<?php
$page = 'students';
include 'connection.php';
//Getting all info of the category.
$query = $con->prepare("SELECT * FROM `students` WHERE `student_id` = :student_id");
$query->bindValue(':student_id', $_GET['id'], PDO::PARAM_INT);
$query->execute();
$s_data = $query->fetch();


if (isset($_POST['edit_student'])) {
    //get user input
    $s_name = $_POST['student_name'];
    $f_name = $_POST['father_name'];
    $m_name = $_POST['mother_name'];
    $s_email = $_POST['email'];
    $s_photo = $s_data['pro_pic'];
    $errors = [];
    $msgs = [];

    //Validate
    if (strlen($s_name) < 4) {
        $errors[] = "Student name must be greater than 4 chars!";
    } else {

        //If image uploaded
        if (!empty($_FILES['pro_pic']['tmp_name'])) {
            $s_photo = time() . $_FILES['pro_pic']['name'];

            $dst = '../uploads/student_photos/' . $s_photo;

            move_uploaded_file($_FILES['pro_pic']['tmp_name'], $dst);
        }
        //if no errors,DB update
        $u_qry = $con->prepare("UPDATE `students` SET `student_name`= :student_name,`father_name`= :father_name,`mother_name`=:mother_name,`email`=:email,`pro_pic`= :pro_pic WHERE `student_id` = :cId");
        $u_qry->bindValue(':cId', $_GET['id'], PDO::PARAM_INT);
        $u_qry->bindValue(':student_name', $s_name);
        $u_qry->bindValue(':father_name', $f_name);
        $u_qry->bindValue(':mother_name', $m_name);
        $u_qry->bindValue(':email', $s_email);
        $u_qry->bindValue(':pro_pic', $s_photo);
        $u_qry->execute();

        //Checking for success
        if ($u_qry->rowCount() === 1) {
            $msgs[] = "Student Updated SUccessfully!";
            //Getting updated info of the category.
            $query = $con->prepare("SELECT * FROM `students` WHERE `student_id` = :student_id");
            $query->bindValue(':student_id', $_GET['id'], PDO::PARAM_INT);
            $query->execute();
            $s_data = $query->fetch();
        } else {
            $errors[] = "Update failed!";
        }
    }
}
?>

<?php include_once 'partials/header.php'; ?>
<!-- Page Content -->
<div class="container">

    <div class="row">

        <?php include_once 'partials/sidebar.php'; ?>
        <!-- /.col-lg-3 -->

        <div class="col-lg-9 col-md-9 mt-4 mb-4">
            <p class="h3">Add Student</p>
            <?php if (!empty($errors)) { ?>
                <div class="alert alert-danger">
                    <?php foreach ($errors as $error) { ?>
                        <p><?php echo $error; ?></p>
                    <?php } ?>
                </div>
            <?php } ?>
            <?php if (!empty($msgs)) { ?>
                <div class="alert alert-success">
                    <?php foreach ($msgs as $msg) { ?>
                        <p><?php echo $msg; ?></p>
                    <?php } ?>
                </div>
            <?php } ?>
            <form action="" method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="student_name">Student Name</label>
                    <input class="form-control" type="text" name="student_name" id="student_name" value="<?php echo $s_data['student_name']; ?>" required="">
                </div>
                <div class="form-group">
                    <label for="father_name">Father Name</label>
                    <input class="form-control" type="text" name="father_name" id="father_name" value="<?php echo $s_data['father_name']; ?>" required="">
                </div>
                <div class="form-group">
                    <label for="mother_name">Mother Name</label>
                    <input class="form-control" type="text" name="mother_name" id="mother_name" value="<?php echo $s_data['mother_name']; ?>" required="">
                </div>
               
                <div class="form-group">
                    <label for="email">Email</label>
                    <input class="form-control" type="email" name="email" value="<?php echo $s_data['email']; ?>" id="email" required="">
                </div>
                <div class="form-group">
                    <label for="pro_pic">Student Photo</label>
                    <img src="../uploads/student_photos/<?php echo $s_data['pro_pic']; ?>" alt="pro_pic" width="100">
                    <input class="form-control" type="file" name="pro_pic" id="pro_pic" >
                </div>

                <button class="btn btn-success" name="edit_student">Edit</button>
                <a href="student.php" class="btn btn-warning">Cancel</a>
            </form>


        </div>
        <!-- /.col-lg-9 -->

    </div>
    <!-- /.row -->

</div>
<!-- /content container -->

<?php include_once 'partials/footer.php'; ?>

