<?php
$page = 'classes';
include 'connection.php';
if (isset($_POST['add_class'])) {
    //take user input
    $class_name = trim($_POST['class_name']);
    $description = trim($_POST['description']);
    $errors = [];
    $msgs = [];


    //IF no error, DB upload
    if (empty($errors)) {

        $query = $con->prepare("INSERT INTO `classes`(`class_name`,`description`) VALUES(:class_name,:description)");
        $query->bindValue('class_name', $class_name);
        $query->bindValue('description', $description);
        $query->execute();

        //Notify the user.
        if ($query->rowCount() === 1) {
            $msgs[] = "Class Added Successfully";
        } else {
            $errors[] = "Class could not be Added";
        }
    }
}
?>

<?php include_once 'partials/header.php'; ?>
<!-- Page Content -->
<div class="container">

    <div class="row">

        <?php include_once 'partials/sidebar.php'; ?>
        <!-- /.col-lg-3 -->

        <div class="col-lg-9 col-md-9 mt-4 mb-4">
            <p class="h3">Add Class</p>
            <?php if (!empty($errors)) { ?>
                <div class="alert alert-danger">
                    <?php foreach ($errors as $error) { ?>
                        <p><?php echo $error; ?></p>
                    <?php } ?>
                </div>
            <?php } ?>
            <?php if (!empty($msgs)) { ?>
                <div class="alert alert-success">
                    <?php foreach ($msgs as $msg) { ?>
                        <p><?php echo $msg; ?></p>
                    <?php } ?>
                </div>
            <?php } ?>
            <form action="" method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="class_name">Class Name</label>
                    <input class="form-control" type="text" name="class_name" id="class_name" required="">
                </div>
                <div class="form-group">
                    <label for="description">Description</label>
                    <input class="form-control" type="text" name="description" id="description" required="">
                </div>
                <div class="form-group">
                   

                <button class="btn btn-success" name="add_class">Add Class</button>
                <a href="class.php" class="btn btn-warning">Cancel</a>
            </form>


        </div>
        <!-- /.col-lg-9 -->

    </div>
    <!-- /.row -->

</div>
<!-- /content container -->

<?php include_once 'partials/footer.php'; ?>
