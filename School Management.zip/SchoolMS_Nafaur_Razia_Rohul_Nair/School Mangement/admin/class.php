<?php
$page = 'classes';
include 'connection.php';

$c_qry = $con->prepare("SELECT * FROM `classes`");
$c_qry->execute();
$c_data = $c_qry->fetchAll();
?>

<?php include_once 'partials/header.php'; ?>
<!-- Page Content -->
<div class="container">

    <div class="row">

        <?php include_once 'partials/sidebar.php'; ?>
        <!-- /.col-lg-3 -->

        <div class="col-md-9 mt-4 mb-4">

            <div class="alert alert-success">
                <a href="add_class.php" class="btn btn-success">Add class</a>
            </div>
            <table class="table table-bordered">
                <tr>
                    <th>Class ID</th>
                    <th>Class Name</th>
                    <th>Description</th>
                    <th>Action</th>
                </tr>
                <?php foreach ($c_data as $class) { ?>
                    <tr>
                        <td><?php echo $class['class_id']; ?></td>
                        <td><?php echo $class['class_name']; ?></td>
                        <td><?php echo $class['description']; ?></td>
                        <td>
                            <a href="edit_class.php?id=<?php echo $class['class_id']; ?>">Edit</a>
                            <a href="delete_class.php?id=<?php echo $class['class_id']; ?>">Delete</a>
                        </td>
                    </tr>
                <?php } ?>
            </table>
            <!-- /.row -->

        </div>
        <!-- /.col-lg-9 -->

    </div>
    <!-- /.row -->

</div>
<!-- /content container -->

<?php include_once 'partials/footer.php'; ?>