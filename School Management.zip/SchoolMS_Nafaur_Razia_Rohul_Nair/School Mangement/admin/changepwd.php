<?php
include 'partials/header.php';
require 'connection.php';


$stmt = $con->prepare("SELECT  `admin_name`, `password` FROM `admins` WHERE `admin_id` = :admin_id");
$stmt->bindValue(':admin_id',$_SESSION['id'],PDO::PARAM_INT);
$stmt->execute();
$admins = $stmt->fetch()
   



?>

<?php
if (isset($_POST['reset'])) {
    //take user input
    $old = trim($_POST['old']);
    $new = trim($_POST['new']);
    $new2 = trim($_POST['new2']);
    $errors = [];
    $msgs = [];
    
    
    if(password_verify($old,$admins['password']) === true){
        
        if($new == $new2){
            $new = password_hash($new,PASSWORD_BCRYPT);
            $qry = $con->prepare("UPDATE `admins` SET `password` = :pwd WHERE `admin_id` = :admin_id");
            $qry->bindValue(':pwd',$new);
            $qry->bindValue('admin_id',$_SESSION['id']);
            $qry->execute();
            
            if($qry->rowCount() === 1){
//               unset($_SESSION);
//               session_destroy();
               header('Location: index.php');
            }
        }else{
            $error[] = "Please check the new passwords!";
        }
        
        
        
    }else{
        $error[] = "Old password didn't match!";
    }

  
    
}

//IF no error, DB upload
?>


<!-- Page Content -->
<div class="container">
    <div class="row">

        <!-- /.col-lg-3 -->
        <div class="col-lg-12">

            <div class="row">
                <div class="col-md-4 mt-4 mb-4 mx-auto">
                    <form action="" method="post">
                        
                        <div class="form-group">
                            <label for="old">Old Password</label>
                            <input class="form-control" type="password" name="old" id="old" required="" placeholder="Type your Old password..">
                        </div>
                        <div class="form-group">
                            <label for="new">New Password</label>
                            <input class="form-control" name="new" id="new" type="password" required="" placeholder="Type your new password..">
                        </div>
                        <div class="form-group">
                            <label for="new2">New Password</label>
                            <input class="form-control" name="new2" id="new2" type="password" required="" placeholder="Retype your new password..">
                        </div>
                        <button class="btn btn-success" name="reset">Reset Password</button>
                        <a href="dashboard.php" class="btn btn-info">Cancel</a>
                    </form>
                </div>

            </div>
            <!-- /.row -->
        </div>
        <!-- /.col-lg-9 -->
    </div>
    <!-- /.row -->
</div>
<!-- /.container -->
<?php include 'partials/footer.php'; ?>
