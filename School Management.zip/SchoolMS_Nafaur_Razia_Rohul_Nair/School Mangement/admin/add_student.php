<?php
$page = 'student';
include 'connection.php';
if (isset($_POST['add_student'])) {
    //take user input
    $student_name = trim($_POST['student_name']);
    $father_name = trim($_POST['father_name']);
    $mother_name = trim($_POST['mother_name']);
    $email= trim($_POST['email']);
    $pro_pic= "";
    $errors = [];
    $msgs = [];
	
    //Validate
    if (strlen($student_name) < 4) {
        $errors[] = "Student Name must be greater than 4 Chars!!";
    }

    //Image Upload
    if (isset($_FILES['pro_pic']['tmp_name'])) {
        $pro_pic = time() . $_FILES['pro_pic']['name'];
        $tmp = $_FILES['pro_pic']['tmp_name'];
        $dst = '../uploads/student_photos/' . $pro_pic;

        move_uploaded_file($tmp, $dst);
    }

    //IF no error, DB upload
    if (empty($errors)) {

        $query = $con->prepare("INSERT INTO `students`(`student_name`,`father_name`,`mother_name`,`email`,`pro_pic`) VALUES(:student_name,:father_name,:mother_name,:email,:pro_pic)");
        $query->bindValue('student_name', $student_name);
        $query->bindValue('father_name', $father_name);
        $query->bindValue('mother_name', $mother_name);
        $query->bindValue('email', $email);
        $query->bindValue('pro_pic', $pro_pic);
        $query->execute();

        //Notify the user.
        if ($query->rowCount() === 1) {
            $msgs[] = "Student Added Successfully";
        } else {
            $errors[] = "Student could not be Added";
        }
    }
}
?>

<?php include_once 'partials/header.php'; ?>
<!-- Page Content -->
<div class="container">

    <div class="row">

        <?php include_once 'partials/sidebar.php'; ?>
        <!-- /.col-lg-3 -->

        <div class="col-lg-9 col-md-9 mt-4 mb-4">
            <p class="h3">Add Student</p>
            <?php if (!empty($errors)) { ?>
                <div class="alert alert-danger">
                    <?php foreach ($errors as $error) { ?>
                        <p><?php echo $error; ?></p>
                    <?php } ?>
                </div>
            <?php } ?>
            <?php if (!empty($msgs)) { ?>
                <div class="alert alert-success">
                    <?php foreach ($msgs as $msg) { ?>
                        <p><?php echo $msg; ?></p>
                    <?php } ?>
                </div>
            <?php } ?>
            <form action="" method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="student_name">Student Name</label>
                    <input class="form-control" type="text" name="student_name" id="student_name" required="">
                </div>
                <div class="form-group">
                    <label for="father_name">Father Name</label>
                    <input class="form-control" type="text" name="father_name" id="father_name" required="">
                </div>
                <div class="form-group">
                    <label for="mother_name">Mother Name</label>
                    <input class="form-control" type="text" name="mother_name" id="mother_name" required="">
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input class="form-control" type="email" name="email" id="email" >
                </div>

                <div class="form-group">
                    <label for="pro_pic">Profile photo</label>
                    <input class="form-control" type="file" name="pro_pic" id="pro_pic" >
                </div>

                <button class="btn btn-success" name="add_student">Add student</button>
                <a href="student.php" class="btn btn-warning">Cancel</a>
            </form>


        </div>
        <!-- /.col-lg-9 -->

    </div>
    <!-- /.row -->

</div>
<!-- /content container -->

<?php include_once 'partials/footer.php'; ?>
