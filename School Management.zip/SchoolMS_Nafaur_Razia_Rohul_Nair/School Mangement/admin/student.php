<?php
$page = 'students';
include 'connection.php';
$s_qry = $con->prepare("SELECT * FROM `students`");
$s_qry->execute();
$s_data = $s_qry->fetchAll();
?>

<?php include_once 'partials/header.php'; ?>
<!-- Page Content -->
<div class="container">

    <div class="row">

        <?php include_once 'partials/sidebar.php'; ?>
        <!-- /.col-lg-3 -->

        <div class="col-md-9 mt-4 mb-4">

            <div class="alert alert-success">
                <a href="add_student.php" class="btn btn-success">Add Student</a>
            </div>
            <table class="table table-bordered">
                <tr>
                    <th>Student ID</th>
                    <th>Student Name</th>
                    <th>Father Name</th>
                    <th>Mother Name</th>
                    <th>Students Email</th>
                    <th>Students Pic</th>
                    <th>Action</th>
                </tr>
                <?php foreach ($s_data as $student) { ?>
                    <tr>
                        <td><?php echo $student['student_id']; ?></td>
                        <td><?php echo $student['student_name']; ?></td>
                        <td><?php echo $student['father_name']; ?></td>
                        <td><?php echo $student['mother_name']; ?></td>
                        <td><?php echo $student['email']; ?></td>

                        <td><img src="../uploads/student_photos/<?php echo $student['pro_pic']; ?>" alt="
                                 pro_pic" width="100"></td>
                        <td>
                            <a href="edit_student.php?id=<?php echo $student['student_id']; ?>">Edit</a>
                            <a href="delete_student.php?id=<?php echo $student['student_id']; ?>">Delete</a>
                        </td>
                    </tr>
                <?php } ?>
            </table>
            <!-- /.row -->

        </div>
        <!-- /.col-lg-9 -->

    </div>
    <!-- /.row -->

</div>
<!-- /content container -->

<?php include_once 'partials/footer.php'; ?>
</div>
<!-- /.row -->


