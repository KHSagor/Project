<?php

include 'connection.php';

if ($_GET['id']) {

    $d_qry = $con->prepare("DELETE FROM `classes` WHERE `class_id` = :class_id");
    $d_qry->bindValue(':class_id', $_GET['id'], PDO::PARAM_INT);
    $d_qry->execute();

    if ($d_qry->rowCount() === 1) {
        $d_qry = $con->prepare("ALTER TABLE `classes` AUTO_INCREMENT = 1");
        $d_qry->execute();
        
        header('Location: class.php');
    }
}
