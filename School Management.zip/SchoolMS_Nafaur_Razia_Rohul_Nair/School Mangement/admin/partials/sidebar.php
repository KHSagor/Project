<div class="col-lg-3">

    <h3 class="my-4">Dashboard</h3>
    <div class="list-group mb-4">
        <a href="notice.php" class="list-group-item">Notices</a>
        <a href="changepwd.php" class="list-group-item">Change Password</a>
        <a href="logout.php" class="list-group-item">Logout</a>
    </div>

</div>