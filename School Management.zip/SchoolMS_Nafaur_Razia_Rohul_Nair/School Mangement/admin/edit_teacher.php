<?php
$page = 'teachers';
include 'connection.php';
//Getting all info of the category.
$query = $con->prepare("SELECT * FROM `teachers` WHERE `teacher_id` = :teacher_id");
$query->bindValue(':teacher_id', $_GET['id'], PDO::PARAM_INT);
$query->execute();
$t_data = $query->fetch();


if (isset($_POST['edit_teacher'])) {
    //get user input
    $t_name = $_POST['teacher_name'];
    $t_desc = $_POST['designation'];
    $t_email = $_POST['email'];
    $t_photo = $t_data['pro_pic'];
    $errors = [];
    $msgs = [];

    //Validate
    if (strlen($t_name) < 4) {
        $errors[] = "Teacher name must be greater than 4 chars!";
    } else {

        //If image uploaded
        if (!empty($_FILES['pro_pic']['tmp_name'])) {
            $t_photo = time() . $_FILES['pro_pic']['name'];

            $dst = '../uploads/teacher_photos/' . $t_photo;

            move_uploaded_file($_FILES['pro_pic']['tmp_name'], $dst);
        }
        //if no errors,DB update
        $u_qry = $con->prepare("UPDATE `teachers` SET `teacher_name`= :teacher_name,`designation`= :designation,`email`=:email,`pro_pic`= :pro_pic WHERE `teacher_id` = :cId");
        $u_qry->bindValue(':cId', $_GET['id'], PDO::PARAM_INT);
        $u_qry->bindValue(':teacher_name', $t_name);
        $u_qry->bindValue(':designation', $t_desc);
        $u_qry->bindValue(':email', $t_email);
        $u_qry->bindValue(':pro_pic', $t_photo);
        $u_qry->execute();

        //Checking for success
        if ($u_qry->rowCount() === 1) {
            $msgs[] = "Teacher Updated SUccessfully!";
            //Getting updated info of the category.
            $query = $con->prepare("SELECT * FROM `teachers` WHERE `teacher_id` = :teacher_id");
            $query->bindValue(':teacher_id', $_GET['id'], PDO::PARAM_INT);
            $query->execute();
            $t_data = $query->fetch();
        } else {
            $errors[] = "Update failed!";
        }
    }
}
?>

<?php include_once 'partials/header.php'; ?>
<!-- Page Content -->
<div class="container">

    <div class="row">

<?php include_once 'partials/sidebar.php'; ?>
        <!-- /.col-lg-3 -->

        <div class="col-lg-9 col-md-9 mt-4 mb-4">
            <p class="h3">Add Teacher</p>
<?php if (!empty($errors)) { ?>
                <div class="alert alert-danger">
                <?php foreach ($errors as $error) { ?>
                        <p><?php echo $error; ?></p>
                    <?php } ?>
                </div>
                <?php } ?>
            <?php if (!empty($msgs)) { ?>
                <div class="alert alert-success">
                <?php foreach ($msgs as $msg) { ?>
                        <p><?php echo $msg; ?></p>
                    <?php } ?>
                </div>
                <?php } ?>
            <form action="" method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="teacher_name">Teacher Name</label>
                    <input class="form-control" type="text" name="teacher_name" id="teacher_name" value="<?php echo $t_data['teacher_name']; ?>" required="">
                </div>
                <div class="form-group">
                    <label for="designation">Designation</label>
                    <input class="form-control" type="text" name="designation" value="<?php echo $t_data['designation']; ?>" id="designation" required="">
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input class="form-control" type="text" name="email" value="<?php echo $t_data['email']; ?>" id="email" required="">
                </div>
                <div class="form-group">
                    <label for="pro_pic">Teacher Photo</label>
                    <img src="../uploads/teacher_photos/<?php echo $t_data['pro_pic']; ?>" alt="pro_pic" width="100">
                    <input class="form-control" type="file" name="pro_pic" id="pro_pic" >
                </div>

                <button class="btn btn-success" name="edit_teacher">Edit</button>
                <a href="teacher.php" class="btn btn-warning">Cancel</a>
            </form>


        </div>
        <!-- /.col-lg-9 -->

    </div>
    <!-- /.row -->

</div>
<!-- /content container -->

<?php include_once 'partials/footer.php'; ?>

