<?php
$page = 'notices';
include 'connection.php';
//Getting all info of the category.
$query = $con->prepare("SELECT * FROM `notices` WHERE `notice_id` = :v");
$query->bindValue(':v', $_GET['id'], PDO::PARAM_INT);
$query->execute();
$n_data = $query->fetch();


if (isset($_POST['edit_notice'])) {
    //get user input
    $s_name = $_POST['notice_head'];
    $f_desc = $_POST['full_desc'];
    $n_photo = $n_data['notice_photo'];
    $errors = [];
    $msgs = [];

    //Validate
    if (strlen($s_name) < 4) {
        $errors[] = "NOtice name must be greater than 4 chars!";
    } else {

        //If image uploaded
        if (!empty($_FILES['notice_photo']['tmp_name'])) {
            $n_photo = time() . $_FILES['notice_photo']['name'];

            $dst = '../uploads/notice_photos/' . $n_photo;

            move_uploaded_file($_FILES['notice_photo']['tmp_name'], $dst);
        }
        //if no errors,DB update
        $u_qry = $con->prepare("UPDATE `notices` SET `notice_head`= :notice_head,`full_desc`= :full_desc,`notice_photo`= :notice_photo WHERE `notice_id` = :cId");
        $u_qry->bindValue(':cId', $_GET['id'], PDO::PARAM_INT);
        $u_qry->bindValue(':notice_head', $s_name);
        $u_qry->bindValue(':full_desc', $f_desc);
        $u_qry->bindValue(':notice_photo', $n_photo);
        $u_qry->execute();

        //Checking for success
        if ($u_qry->rowCount() === 1) {
            $msgs[] = "Notice Updated SUccessfully!";
            //Getting updated info of the category.
            $query = $con->prepare("SELECT * FROM `notices` WHERE `notice_id` = :notice_id");
            $query->bindValue(':notice_id', $_GET['id'], PDO::PARAM_INT);
            $query->execute();
            $n_data = $query->fetch();
        } else {
            $errors[] = "Update failed!";
        }
    }
}
?>

<?php include_once 'partials/header.php'; ?>
<!-- Page Content -->
<div class="container">

    <div class="row">

        <?php include_once 'partials/sidebar.php'; ?>
        <!-- /.col-lg-3 -->

        <div class="col-lg-9 col-md-9 mt-4 mb-4">
            <p class="h3">Add Notice</p>
            <?php if (!empty($errors)) { ?>
                <div class="alert alert-danger">
                    <?php foreach ($errors as $error) { ?>
                        <p><?php echo $error; ?></p>
                    <?php } ?>
                </div>
            <?php } ?>
            <?php if (!empty($msgs)) { ?>
                <div class="alert alert-success">
                    <?php foreach ($msgs as $msg) { ?>
                        <p><?php echo $msg; ?></p>
                    <?php } ?>
                </div>
            <?php } ?>
            <form action="" method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="notice_head">Student Name</label>
                    <input class="form-control" type="text" name="notice_head" id="notice_head" value="<?php echo $n_data['notice_head']; ?>" required="">
                </div>
                <div class="form-group">
                    <label for="full_desc">Full Description</label>
                    <input class="form-control" type="text" name="full_desc" id="full_desc" value="<?php echo $n_data['full_desc']; ?>" required="">
                </div>
                <div class="form-group">
                    <label for="notice_photo">Notice Photo</label>
                    <img src="../uploads/notice_photos/<?php echo $n_data['notice_photo']; ?>" alt="notice_photo" width="100">
                    <input class="form-control" type="file" name="notice_photo" id="notice_photo" >
                </div>
                <button class="btn btn-success" name="edit_notice">Edit</button>
                <a href="notice.php" class="btn btn-warning">Cancel</a>
            </form>


        </div>
        <!-- /.col-lg-9 -->

    </div>
    <!-- /.row -->

</div>
<!-- /content container -->

<?php include_once 'partials/footer.php'; ?>

