<?php
$page = 'teacher';
include 'connection.php';
if (isset($_POST['add_cat'])) {
    //take user input
    $teacher_name = trim($_POST['teacher_name']);
    $designation = trim($_POST['designation']);
    $email= trim($_POST['email']);
    $pro_pic= "";
    $errors = [];
    $msgs = [];

    //Validate
    if (strlen($teacher_name) < 4) {
        $errors[] = "Category Name must be greater than 4 Chars!!";
    }

    //Image Upload
    if (isset($_FILES['pro_pic']['tmp_name'])) {
        $pro_pic = time() . $_FILES['pro_pic']['name'];
        $tmp = $_FILES['pro_pic']['tmp_name'];
        $dst = '../uploads/teacher_photos/' . $pro_pic;

        move_uploaded_file($tmp, $dst);
    }

    //IF no error, DB upload
    if (empty($errors)) {

        $query = $con->prepare("INSERT INTO `teachers`(`teacher_name`,`designation`,`email`,`pro_pic`) VALUES(:teacher_name,:designation,:email,:pro_pic)");
        $query->bindValue('teacher_name', $teacher_name);
        $query->bindValue('designation', $designation);
        $query->bindValue('email', $email);
        $query->bindValue('pro_pic', $pro_pic);
        $query->execute();

        //Notify the user.
        if ($query->rowCount() === 1) {
            $msgs[] = "Teacher Added Successfully";
        } else {
            $errors[] = "Teacher could not be Added";
        }
    }
}
?>

<?php include_once 'partials/header.php'; ?>
<!-- Page Content -->
<div class="container">

    <div class="row">

        <?php include_once 'partials/sidebar.php'; ?>
        <!-- /.col-lg-3 -->

        <div class="col-lg-9 col-md-9 mt-4 mb-4">
            <p class="h3">Add Teacher</p>
            <?php if (!empty($errors)) { ?>
                <div class="alert alert-danger">
                    <?php foreach ($errors as $error) { ?>
                        <p><?php echo $error; ?></p>
                    <?php } ?>
                </div>
            <?php } ?>
            <?php if (!empty($msgs)) { ?>
                <div class="alert alert-success">
                    <?php foreach ($msgs as $msg) { ?>
                        <p><?php echo $msg; ?></p>
                    <?php } ?>
                </div>
            <?php } ?>
            <form action="" method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="cat_name">Teacher Name</label>
                    <input class="form-control" type="text" name="teacher_name" id="teacher_name" required="">
                </div>
                <div class="form-group">
                    <label for="cat_desc">Designation</label>
                    <input class="form-control" type="text" name="designation" id="designation" required="">
                </div>
                <div class="form-group">
                    <label for="cat_photo">Email</label>
                    <input class="form-control" type="email" name="email" id="email" >
                </div>

                <div class="form-group">
                    <label for="cat_photo">Profile photo</label>
                    <input class="form-control" type="file" name="pro_pic" id="pro_pic" >
                </div>

                <button class="btn btn-success" name="add_cat">Add Teacher</button>
                <a href="category.php" class="btn btn-warning">Cancel</a>
            </form>


        </div>
        <!-- /.col-lg-9 -->

    </div>
    <!-- /.row -->

</div>
<!-- /content container -->

<?php include_once 'partials/footer.php'; ?>
