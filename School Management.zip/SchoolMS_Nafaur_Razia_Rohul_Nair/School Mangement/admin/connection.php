<?php

$dsn = 'mysql:host=localhost;dbname=school_pro';
$user = 'root';
$password = '';

try{
    $con = new PDO($dsn,  $user,$password);
    //change the default errormode
    $con->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
      //change the default fetch
    $con->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE,PDO::FETCH_ASSOC);
//    echo "Database Connection Successfull!!";
} catch (Exception $e) {
    echo 'Database connection failed!'.$e->getMessage();
}
