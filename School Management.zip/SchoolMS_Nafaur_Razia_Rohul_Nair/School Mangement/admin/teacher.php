<?php
$page = 'teacher';
include 'connection.php';

$t_qry = $con->prepare("SELECT * FROM `teachers`");
$t_qry->execute();
$t_data = $t_qry->fetchAll();

?>

<?php include_once 'partials/header.php'; ?>
<!-- Page Content -->
<div class="container">

    <div class="row">

        <?php include_once 'partials/sidebar.php'; ?>
        <!-- /.col-lg-3 -->

        <div class="col-md-9 mt-4 mb-4">

            <div class="alert alert-success">
                <a href="add_teacher.php" class="btn btn-success">Add Teacher</a>
            </div>
            <table class="table table-bordered">
                <tr>
                    <th>Teacher ID</th>
                    <th>Teacher Name</th>
                    <th>Teacher Designation</th>
                    <th>Teacher Email</th>
                    <th>Teacher Photo</th>
                    <th>Action</th>
                </tr>
                <?php foreach ($t_data as $teacher) { ?>
                    <tr>
                        <td><?php echo $teacher['teacher_id']; ?></td>
                        <td><?php echo $teacher['teacher_name']; ?></td>
                        <td><?php echo $teacher['designation']; ?></td>
                        <td><?php echo $teacher['email']; ?></td>
                        
                        <td><img src="../uploads/teacher_photos/<?php echo $teacher['pro_pic']; ?>" alt="
                                 teacher_photos" width="100"></td>
                        <td>
                            <a href="edit_teacher.php?id=<?php echo $teacher['teacher_id']; ?>">Edit</a>
                            <a href="delete_teacher.php?id=<?php echo $teacher['teacher_id']; ?>">Delete</a>
                        </td>
                    </tr>
                <?php } ?>
            </table>
            <!-- /.row -->

        </div>
        <!-- /.col-lg-9 -->

    </div>
    <!-- /.row -->

</div>
<!-- /content container -->

<?php include_once 'partials/footer.php'; ?>