<?php include 'partials/header.php';
include 'connection.php'; ?>

<?php

if (isset($_POST['register'])) {
    //take user input
    $uname = trim($_POST['uname']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $pro_pic = '';
    $errors = [];
    $msgs = [];


    //Validate
    if (strlen($uname) < 6) {
        $errors[] = "Username must be greater than  6 Chars!!";
    }
    if (strlen($password) < 6) {
        $errors[] = "Password must be greater than  6 Chars!!";
    }
    if (filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
        $errors[] = "Please enter a valid email!";
    }
    
    //Image Upload
    if(isset($_FILES['pro_pic']['tmp_name'])){
        $pro_pic = time().$_FILES['pro_pic']['name'];
        $tmp = $_FILES['pro_pic']['tmp_name'];
        $dst = '../uploads/admin_photos/'.$pro_pic;
        
        move_uploaded_file($tmp,$dst);
    }
    
    //IF no error, DB upload
    if(empty($errors)){  
        $password = password_hash($password,PASSWORD_BCRYPT);
        $query = $con->prepare("INSERT INTO `admins`(`admin_name`,`email`,`password`,`pro_pic`) VALUES(:uname,:email,:password,:pro_pic)");
        $query->bindValue(':uname',  strtolower($uname));
        $query->bindValue(':email',strtolower($email));
        $query->bindValue(':password',$password);
        $query->bindValue(':pro_pic',$pro_pic);
        $query->execute();
        
        //Notify the user.
        if($query->rowCount() === 1){
            $msgs[] = "Registration Done Successfully";
        }else{
            $errors[] = "Registration Error!";
        }  
    }
}

//IF no error, DB upload

?>



<!-- Page Content -->
<div class="container">
    <div class="row">

        <!-- /.col-lg-3 -->
        <div class="col-lg-12">

            <div class="row">

                <div class="col-md-4 mt-4 mb-4 mx-auto">
                    <form action="" method="post" enctype="multipart/form-data">
<?php if (!empty($errors)) { ?>
                            <div class="alert alert-danger">
    <?php foreach ($errors as $error) { ?>
                                    <p><?php echo $error; ?></p>
                            <?php } ?>
                            </div>
                            <?php } ?>
                            <?php if (!empty($msgs)) { ?>
                            <div class="alert alert-success">
                                <?php foreach ($msgs as $msg) { ?>
                                    <p><?php echo $msg; ?></p>
                            <?php } ?>
                            </div>
                            <?php } ?>
                        <div class="form-group">
                            <label for="uname">Username</label>
                            <input class="form-control" type="text" name="uname" id="uname" required="">
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input class="form-control" type="email" name="email" id="email" required="">
                        </div>
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input class="form-control" name="password" id="password" type="password" required="">
                        </div>
                        <div class="form-group">
                            <label for="pro_pic">Profile Photo</label>
                            <input class="form-control" name="pro_pic" id="pro_pic" type="file">
                        </div>
                        <button class="btn btn-success" name="register">Register</button>
                        <a href="index.php" class="btn btn-info">Login</a>
                    </form>
                </div>

            </div>
            <!-- /.row -->
        </div>
        <!-- /.col-lg-9 -->
    </div>
    <!-- /.row -->
</div>
<!-- /.container -->
<?php include 'partials/footer.php'; ?>
