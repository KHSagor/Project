<?php
include 'connection.php';

include 'partials/header.php';
?>
<?php include 'admin/connection.php'; ?>
<body >
    <div class="navbar navbar-inverse navbar-fixed-top " id="menu">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#"><img class="logo-custom" src="assets/img/logo.png" alt=""  /></a>
            </div>
            <div class="navbar-collapse collapse move-me">
                <ul class="nav navbar-nav navbar-right">
                    <li ><a href="#home">HOME</a></li>
                    <li><a href="#features-sec">TEACHERS</a></li>
                    <li><a href="#faculty-sec">STUDENTS</a></li>
                    <li><a href="#course-sec">CLASSES</a></li>
                    <li><a href="#notice-sec">NOTICES</a></li>
                    <li><a href="#contact-sec">CONTACT</a></li>
                </ul>
            </div>
        </div>
    </div>
    <!--NAVBAR SECTION END-->
    <?php include 'partials/home.php'; ?>
    <!--HOME SECTION END-->   
    <div  class="tag-line" >
        <div class="container">
            <div class="row  text-center" >
                <div class="col-lg-12  col-md-12 col-sm-12">
                    <h2 data-scroll-reveal="enter from the bottom after 0.1s" ><i class="fa fa-circle-o-notch"></i> WELCOME TO THE ALOR MISIL SCHOOL <i class="fa fa-circle-o-notch"></i> </h2>
                </div>
            </div>
        </div>
    </div>
    <!--HOME SECTION TAG LINE END-->   
    <?php include 'partials/teacher.php'; ?>

    <?php include 'partials/student.php'; ?>

    <?php include 'partials/class.php'; ?>
    <?php include 'partials/notice.php'; ?>

    <?php include 'partials/contact.php'; ?>

    <?php include 'partials/location.php'; ?>

    <?php include 'partials/footer.php'; ?>