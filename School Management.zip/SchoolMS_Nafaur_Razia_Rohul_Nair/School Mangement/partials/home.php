    <div class="home-sec" id="home" >
        <div class="overlay">
            <div class="container">
                <div class="row text-center " >

                    <div class="col-lg-12  col-md-12 col-sm-12">

                        <div class="flexslider set-flexi" id="main-section" >
                            <ul class="slides move-me">
                                <!-- Slider 01 -->
                                <li>
                                    <h3>Delivering Quality Education</h3>
                                    <h1>THE UNIQUE METHOD</h1>
                                    <a  href="#features-sec" class="btn btn-info btn-lg" >
                                        GET AWESOME 
                                    </a>
                                    <a  href="#features-sec" class="btn btn-success btn-lg" >
                                        FEATURE LIST
                                    </a>
                                </li>
                                <!-- End Slider 01 -->

                                <!-- Slider 02 -->
                                <li>
                                    <h3>Delivering Quality Education</h3>
                                    <h1>UNMATCHED APPROACH</h1>
                                    <a  href="#features-sec" class="btn btn-primary btn-lg" >
                                        GET AWESOME 
                                    </a>
                                    <a  href="#features-sec" class="btn btn-danger btn-lg" >
                                        FEATURE LIST
                                    </a>
                                </li>
                                <!-- End Slider 02 -->

                                <!-- Slider 03 -->
                                <li>
                                    <h3>Delivering Quality Education</h3>
                                    <h1>AWESOME FACULTY PANEL</h1>
                                    <a  href="#features-sec" class="btn btn-default btn-lg" >
                                        GET AWESOME 
                                    </a>
                                    <a  href="#features-sec" class="btn btn-info btn-lg" >
                                        FEATURE LIST
                                    </a>
                                </li>
                                <!-- End Slider 03 -->
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
