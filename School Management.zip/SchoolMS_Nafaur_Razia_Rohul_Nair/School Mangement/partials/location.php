<div class="container">
        <div class="row set-row-pad"  >
            <div class="col-lg-4 col-md-4 col-sm-4   col-lg-offset-1 col-md-offset-1 col-sm-offset-1 " data-scroll-reveal="enter from the bottom after 0.4s">

                <h2 ><strong>Our Location </strong></h2>
                <hr />
                <div>
                    <h4>Rangpur Sadar</h4>
                    <h4>Rangpur,Bangladesh</h4>
                    <h4><strong>Call:</strong>  0521-63532</h4>
                    <h4><strong>Email: </strong>info@ams.com</h4>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4   col-lg-offset-1 col-md-offset-1 col-sm-offset-1" data-scroll-reveal="enter from the bottom after 0.4s">

                <h2 ><strong>Social Conectivity </strong></h2>
                <hr />
                <div >
                    <a href="#">  <img src="assets/img/Social/facebook.png" alt="" /> </a>
                    <a href="#"> <img src="assets/img/Social/google-plus.png" alt="" /></a>
                    <a href="#"> <img src="assets/img/Social/twitter.png" alt="" /></a>
                </div>
            </div>
        </div>
    </div>