 <?php

 $stmt = $con->prepare("SELECT * FROM  `students`");
 $stmt->execute();
 $t_data = $stmt->fetchAll();
 
 ?>

<div id="faculty-sec" >
        <div class="container set-pad">
            <div class="row text-center">
                <div class="col-lg-8 col-lg-offset-2 col-md-8 col-sm-8 col-md-offset-2 col-sm-offset-2">
                    <h1 data-scroll-reveal="enter from the bottom after 0.1s" class="header-line">OUR STUDENTS</h1>
                    <p data-scroll-reveal="enter from the bottom after 0.3s">
                        Lorem ipsum dolor sit amet, consectetuer adipiscing elit.
                        Aenean commodo.
                        Lorem ipsum dolor sit amet, consectetuer adipiscing elit.
                        Aenean commodo.
                    </p>
                </div>

            </div>
            <!--/.HEADER LINE END-->

            <div class="row" >
                <?php foreach($t_data as $td){?>
                <div class="col-lg-4  col-md-4 col-sm-4" data-scroll-reveal="enter from the bottom after 0.4s">
                    <div class="faculty-div">
                        <img src="uploads/student_photos/<?php echo $td['pro_pic'];?>"  class="img-rounded img-responsive" />
                        <h3 ><?php echo $td['student_name'];?></h3>
                        <hr />
                        <h4><?php echo $td['email'];?><br />CSE</h4>                  
                    </div>
                </div>
                <?php }?>
            </div>
        </div>
    </div>