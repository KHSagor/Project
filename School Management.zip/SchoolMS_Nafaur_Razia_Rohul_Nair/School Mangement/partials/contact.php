<div id="contact-sec"   >
        <div class="overlay">
            <div class="container set-pad">
                <div class="row text-center">
                    <div class="col-lg-8 col-lg-offset-2 col-md-8 col-sm-8 col-md-offset-2 col-sm-offset-2">
                        <h1 data-scroll-reveal="enter from the bottom after 0.1s" class="header-line" >CONTACT US  </h1>
                        <p data-scroll-reveal="enter from the bottom after 0.3s">
                            Lorem ipsum dolor sit amet, consectetuer adipiscing elit.
                            Aenean commodo.
                            Lorem ipsum dolor sit amet, consectetuer adipiscing elit.
                            Aenean commodo.
                        </p>
                    </div>

                </div>
                <!--/.HEADER LINE END-->
                <div class="row set-row-pad"  data-scroll-reveal="enter from the bottom after 0.5s" >
                    <div class="col-lg-8 col-lg-offset-2 col-md-8 col-md-offset-2 col-sm-8 col-sm-offset-2">
                        <form>
                            <div class="form-group">
                                <input type="text" class="form-control "  required="required" placeholder="Your Name" />
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control " required="required"  placeholder="Your Email" />
                            </div>
                            <div class="form-group">
                                <textarea name="message" required="required" class="form-control" style="min-height: 150px;" placeholder="Message"></textarea>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-info btn-block btn-lg">SUBMIT REQUEST</button>
                            </div>  
                        </form>
                    </div>
                </div>
            </div>
        </div> 
    </div>