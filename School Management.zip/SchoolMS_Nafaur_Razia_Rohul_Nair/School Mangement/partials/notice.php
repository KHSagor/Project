<?php
$stmt = $con->prepare("SELECT * FROM  `notices`");
$stmt->execute();
$t_data = $stmt->fetchAll();
?>

<div id="notice-sec" class="container set-pad">
        <div class="row text-center">
            <div class="col-lg-8 col-lg-offset-2 col-md-8 col-sm-8 col-md-offset-2 col-sm-offset-2">
                <h1 data-scroll-reveal="enter from the bottom after 0.1s" class="header-line">OUR Notices</h1>
                <p data-scroll-reveal="enter from the bottom after 0.3s">
                    Lorem ipsum dolor sit amet, consectetuer adipiscing elit.
                    Aenean commodo.
                    Lorem ipsum dolor sit amet, consectetuer adipiscing elit.
                    Aenean commodo.
                </p>
            </div>
        </div>
        <!--/.HEADER LINE END-->

       <div class="row" >
                <?php foreach($t_data as $td){?>
                <div class="col-lg-4  col-md-4 col-sm-4" data-scroll-reveal="enter from the bottom after 0.4s">
                    <div class="notice-div">
                        
                        <h3 ><?php echo $td['notice_head'];?></h3><br>
                        <h6>Posted on <?php echo $td['created_at'];?></h6>
                        <hr>  
                         <h4><?php echo $td['full_desc'];?></h4>
                         <hr>
                          <img src="uploads/notice_photos/<?php echo $td['notice_photo']; ?>"  class="img-rounded img-responsive" />
                          
                    </div>
                </div>
                <?php }?>
            </div>
    </div>