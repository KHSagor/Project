<?php
$stmt = $con->prepare("SELECT * FROM  `classes`");
$stmt->execute();
$t_data = $stmt->fetchAll();
?>

<div id="course-sec" class="container set-pad">
        <div class="row text-center">
            <div class="col-lg-8 col-lg-offset-2 col-md-8 col-sm-8 col-md-offset-2 col-sm-offset-2">
                <h1 data-scroll-reveal="enter from the bottom after 0.1s" class="header-line">OUR CLASSES </h1>
                <p data-scroll-reveal="enter from the bottom after 0.3s">
                    Lorem ipsum dolor sit amet, consectetuer adipiscing elit.
                    Aenean commodo.
                    Lorem ipsum dolor sit amet, consectetuer adipiscing elit.
                    Aenean commodo.
                </p>
            </div>
        </div>
        <!--/.HEADER LINE END-->

       <div class="row" >
                <?php foreach($t_data as $td){?>
                <div class="col-lg-4  col-md-4 col-sm-4" data-scroll-reveal="enter from the bottom after 0.4s">
                    <div class="faculty-div">
                        
                        <h3 ><?php echo $td['class_name'];?></h3>
                        <hr> 
                        <h4><?php echo $td['description'];?><br /></h4> 
                    </div>
                </div>
                <?php }?>
            </div>
    </div>