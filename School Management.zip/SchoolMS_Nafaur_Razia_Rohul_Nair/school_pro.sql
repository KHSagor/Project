-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 27, 2018 at 07:09 AM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `school_pro`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `admin_id` int(11) NOT NULL,
  `admin_name` varchar(32) NOT NULL,
  `email` varchar(64) NOT NULL,
  `password` varchar(250) NOT NULL,
  `pro_pic` varchar(64) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`admin_id`, `admin_name`, `email`, `password`, `pro_pic`) VALUES
(2, 'lemon05', 'lemon05@gmail.com', '$2y$10$dGQLks.rJuC2faAL.GlyE.aCQSr0/umK4dcYRsOTQE1ZwDIbzSPgK', '152212470710000.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `classes`
--

CREATE TABLE `classes` (
  `class_id` int(11) NOT NULL,
  `class_name` varchar(64) NOT NULL,
  `description` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `classes`
--

INSERT INTO `classes` (`class_id`, `class_name`, `description`) VALUES
(1, 'Gallery Room', 'For lessons that require specific resources or a vocational approach, different types of classrooms both indoors and outdoors are used. This allows for learning in an authentic context that fosters the natural development of the particular vocational skill.'),
(2, 'Laboratory', 'Laboratory equipment refers to the various tools and equipment used by scientists working in a laboratory: The classical equipment includes tools such as Bunsen burners and microscopes as well as specialty equipment such as operant conditioning chambers, spectrophotometers and calorimeters. Chemical laboratories.');

-- --------------------------------------------------------

--
-- Table structure for table `notices`
--

CREATE TABLE `notices` (
  `notice_id` int(11) NOT NULL,
  `notice_head` varchar(128) NOT NULL,
  `full_desc` text NOT NULL,
  `notice_photo` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `notices`
--

INSERT INTO `notices` (`notice_id`, `notice_head`, `full_desc`, `notice_photo`, `created_at`) VALUES
(1, 'Sports Day', 'This is to inform to all the concern that the Annual Sports Day 2017.The venue and the timing for the said program is as follows:-  Date: 9th Feb, Thursday, 201  Venue: Symoli Club Field  Time: 8:00 am to 2:00 pm  You are cordially invited for the said program.', '1522127065ResizedImage600400-IMG-10.jpg', '2018-03-27 11:03:55'),
(2, 'Victory Day celebration', 'Victory day (Bengali: à¦¬à¦¿à¦œà¦¯à¦¼ à¦¦à¦¿à¦¬à¦¸)is a national holiday in Bangladesh celebrated on December 16 to commemorate the victory of the allied forces over the Pakistani forces in the Bangladesh Liberation War in 1971.', '1522127133Annual_Sports_Gala_2012_-_PT_Display_by_Junior_Students.JPG', '2018-03-27 11:05:33');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `student_id` int(11) NOT NULL,
  `student_name` varchar(64) NOT NULL,
  `father_name` varchar(64) NOT NULL,
  `mother_name` varchar(64) NOT NULL,
  `email` varchar(64) NOT NULL,
  `pro_pic` varchar(64) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`student_id`, `student_name`, `father_name`, `mother_name`, `email`, `pro_pic`) VALUES
(3, 'NAFAUR RAHMAN', 'Abdus Sabur', 'Nishat Ara', 'rnafaur@gmail.com', '152212556610000.jpg'),
(4, 'FARIDA YEASMIN DIPIKA', 'MD. Yusuf Ali', 'Mst. Roushan Ara', 'dipika07@gmail.com', '1522125868DSC_0550.JPG');

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `teacher_id` int(11) NOT NULL,
  `teacher_name` varchar(64) NOT NULL,
  `designation` varchar(64) DEFAULT NULL,
  `email` varchar(64) NOT NULL,
  `pro_pic` varchar(64) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`teacher_id`, `teacher_name`, `designation`, `email`, `pro_pic`) VALUES
(4, 'RAZIAA SULTANA TRIPTI', 'Lecturer', 'razia58@gmail.com', '1522126189DSC_0627.JPG'),
(5, 'KHADIZA SHILA', 'Lecturer', 'shila49@gmail.com', '1522125405DSC_0273.JPG');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`admin_id`),
  ADD UNIQUE KEY `admins_name` (`admin_name`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `classes`
--
ALTER TABLE `classes`
  ADD PRIMARY KEY (`class_id`),
  ADD UNIQUE KEY `class_name` (`class_name`);

--
-- Indexes for table `notices`
--
ALTER TABLE `notices`
  ADD PRIMARY KEY (`notice_id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`student_id`),
  ADD UNIQUE KEY `student_name` (`student_name`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`teacher_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `classes`
--
ALTER TABLE `classes`
  MODIFY `class_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `notices`
--
ALTER TABLE `notices`
  MODIFY `notice_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `teachers`
--
ALTER TABLE `teachers`
  MODIFY `teacher_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
